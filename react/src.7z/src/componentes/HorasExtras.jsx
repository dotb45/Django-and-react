import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const HorasExtras = () => {
    const { id } = useParams();
    const [nomina, setNomina] = useState(null);
    const [formData, setFormData] = useState({
        horas_extras_diurnas: '',
        horas_extras_nocturnas: '',
        horas_extras_diurnas_dominicales: ''
    });
    const navigate = useNavigate();

    useEffect(() => {
        const obtenerNomina = async () => {
            try {
                const res = await axios.get(`http://localhost:8000/nomina/nominarest/${id}/`);
                setNomina(res.data);
            } catch (error) {
                console.error('Error al obtener la nómina', error);
            }
        };
        obtenerNomina();
    }, [id]);

    const calcularNuevoSueldo = (sueldo, horas_extras_diurnas, horas_extras_nocturnas, horas_extras_diurnas_dominicales) => {
        const valor_hora = sueldo / 235;
        const valor_hora_extra_diurna = valor_hora * 1.25;
        const valor_hora_extra_nocturna = valor_hora * 1.75;
        const valor_hora_extra_diurna_dominical = valor_hora * 2.0;
        const total_extras = (horas_extras_diurnas * valor_hora_extra_diurna) + (horas_extras_nocturnas * valor_hora_extra_nocturna) + (horas_extras_diurnas_dominicales * valor_hora_extra_diurna_dominical);
        return sueldo + total_extras;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (nomina) {
            const nuevoSueldo = calcularNuevoSueldo(
                nomina.sueldo,
                parseFloat(formData.horas_extras_diurnas) || 0,
                parseFloat(formData.horas_extras_nocturnas) || 0,
                parseFloat(formData.horas_extras_diurnas_dominicales) || 0
            );

            try {
                await axios.post(`http://localhost:8000/nomina/actualizar_horas_extras/${id}/`, {
                    ...formData,
                    sueldo: nuevoSueldo
                });
                navigate('/'); // Verifica que esta ruta exista en tu enrutador
            } catch (error) {
                console.error('Error al actualizar horas extras', error);
            }
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    if (!nomina) {
        return <div>Cargando datos...</div>;
    }

    return (
        <div className="container">
            <h2>Actualizar Horas Extras</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Horas Extras Diurnas:</label>
                    <input type="number" className="form-control" name="horas_extras_diurnas" value={formData.horas_extras_diurnas} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Horas Extras Nocturnas:</label>
                    <input type="number" className="form-control" name="horas_extras_nocturnas" value={formData.horas_extras_nocturnas} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Horas Extras Diurnas Dominicales:</label>
                    <input type="number" className="form-control" name="horas_extras_diurnas_dominicales" value={formData.horas_extras_diurnas_dominicales} onChange={handleChange} />
                </div>
                <button type="submit" className="btn btn-primary">Actualizar</button>
            </form>
        </div>
    );
};

export default HorasExtras;
