import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import './Calculos.css';

const Calculos = () => {
    const { id } = useParams();
    const [nomina, setNomina] = useState(null);

    useEffect(() => {
        document.body.classList.add('calculos'); // Añadir clase específica al body

        return () => {
            document.body.classList.remove('calculos'); // Limpiar la clase al desmontar el componente
        };
    }, []);

    useEffect(() => {
        const obtenerNomina = async () => {
            try {
                const res = await axios.get(`http://localhost:8000/nomina/nominarest/${id}/`);
                setNomina(res.data);
            } catch (error) {
                console.error('Error al obtener la nómina', error);
            }
        };
        obtenerNomina();
    }, [id]);

    if (!nomina) {
        return <div>Cargando cálculos...</div>;
    }

    const calcularPensiones = (tipo_empleado, salario) => {
        salario = parseFloat(salario);
        if (tipo_empleado.toUpperCase() === 'I') {
            const base = salario * 0.40;
            return base * 0.16;
        } else if (tipo_empleado.toUpperCase() === 'D') {
            return salario * 0.04;
        } else {
            throw new Error("Tipo de empleado no válido");
        }
    };

    const calcularSalud = (tipo_empleado, salario) => {
        salario = parseFloat(salario);
        if (tipo_empleado.toUpperCase() === 'I') {
            const base = salario * 0.40;
            return base * 0.125;
        } else if (tipo_empleado.toUpperCase() === 'D') {
            return salario * 0.04;
        } else {
            throw new Error("Tipo de empleado no válido");
        }
    };

    const baseCotizacion = (tipo_empleado, salario) => {
        if (tipo_empleado.toUpperCase() === 'I') {
            return salario * 0.40;
        } else if (tipo_empleado.toUpperCase() === 'D') {
            return salario;
        } else {
            throw new Error("Tipo de empleado no válido");
        }
    };

    const calcularARL = (nivel_riesgo, salario) => {
        const arl_percent = {
            '1': 0.00522,
            '2': 0.01044,
            '3': 0.02436,
            '4': 0.04350,
            '5': 0.06960
        };
        if (!arl_percent[nivel_riesgo]) {
            throw new Error("Nivel de riesgo no válido");
        }
        return salario * arl_percent[nivel_riesgo];
    };

    const calcularCajaCompensacion = (tipo_empleado, salario) => {
        if (tipo_empleado.toUpperCase() === 'D') {
            return salario * 0.04;
        }
        return 0;
    };

    const calcularPrima = (salario) => {
        return salario / 12;
    };

    const calcularAuxilioTransporte = (salario) => {
        const auxilio_transporte = 140606;
        const salario_minimo = 1300000;
        if (salario <= (2 * salario_minimo)) {
            return auxilio_transporte;
        }
        return 0;
    };

    const pensiones = calcularPensiones(nomina.estado, nomina.sueldo);
    const salud = calcularSalud(nomina.estado, nomina.sueldo);
    const base = baseCotizacion(nomina.estado, nomina.sueldo);
    const arl = calcularARL(nomina.nivel_riesgo, nomina.sueldo);
    const caja_compensacion = calcularCajaCompensacion(nomina.estado, nomina.sueldo);
    const prima = calcularPrima(nomina.sueldo);
    const auxilio_transporte = calcularAuxilioTransporte(nomina.sueldo);

    return (
        <div className="calculos-container">
            <h2>Cálculos del empleado</h2>
            <table className="table table-striped mt-4">
                <tbody>
                    <tr>
                        <th>Nombre</th>
                        <td>{nomina.nombre}</td>
                    </tr>
                    <tr>
                        <th>Apellido</th>
                        <td>{nomina.apellido}</td>
                    </tr>
                    <tr>
                        <th>Documento</th>
                        <td>{nomina.documento}</td>
                    </tr>
                    <tr>
                        <th>Pensiones</th>
                        <td>{pensiones.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <th>Salud</th>
                        <td>{salud.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <th>Base</th>
                        <td>{base.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <th>ARL</th>
                        <td>{arl.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <th>Caja de Compensación</th>
                        <td>{caja_compensacion.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <th>Prima</th>
                        <td>{prima.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <th>Auxilio de Transporte</th>
                        <td>{auxilio_transporte.toFixed(2)}</td>
                    </tr>
                </tbody>
            </table>
            <Link to="/">
                <button className="btn btn-primary mt-3">Ir a la lista</button>
            </Link>
        </div>
    );
};

export default Calculos;
