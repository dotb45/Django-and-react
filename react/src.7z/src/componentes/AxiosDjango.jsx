import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import './AxiosDjango.css';

const AxiosDjango = () => {
    const [users, setUsers] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const cargarUsuarios = async () => {
            const res = await axios('http://localhost:8000/nomina/nominarest/');
            setUsers(res.data);
        };
        cargarUsuarios();
    }, []);

    const eliminarUsuario = async (id) => {
        try {
            await axios.delete(`http://localhost:8000/nomina/nominarest/${id}/`);
            setUsers(users.filter((user) => user.id !== id));
        } catch (error) {
            console.error('Error al eliminar el usuario', error);
        }
    };

    const calcular = (id) => {
        navigate(`/calculos/${id}`);
    };

    const actualizarHorasExtras = (id) => {
        navigate(`/horasextras/${id}`);
    };

    return (
        <div className="axios-container">
            <div className="axios header">
                <h1 className="axios title">Usuarios</h1>
                <Link to="/form" className="axios btn axios btn-primary">
                    Ir al Formulario
                </Link>
            </div>
            <table className="axios table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Documento</th>
                        <th>Género</th>
                        <th>Estado</th>
                        <th>Email</th>
                        <th>Sueldo</th>
                        <th>Foto</th>
                        <th>Nivel de riesgo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((usr) => (
                        <tr key={usr.id}>
                            <td>{usr.nombre}</td>
                            <td>{usr.apellido}</td>
                            <td>{usr.documento}</td>
                            <td>{usr.genero}</td>
                            <td>{usr.estado}</td>
                            <td>{usr.email}</td>
                            <td>{usr.sueldo}</td>
                            <td>
                                <img alt="User" src={usr.photo} />
                            </td>
                            <td>{usr.nivel_riesgo}</td>
                            <td className="axios actions">
                                <button
                                    onClick={() => calcular(usr.id)}
                                    className="axios btn axios btn-info"
                                >
                                    Calcular
                                </button>
                                <button
                                    onClick={() => actualizarHorasExtras(usr.id)}
                                    className="axios btn axios btn-info"
                                >
                                    Horas Extras
                                </button>
                                <Link to={`/editar/${usr.id}`} className="axios btn axios btn-warning">
                                    Editar
                                </Link>
                                <button
                                    onClick={() => eliminarUsuario(usr.id)}
                                    className="axios btn axios btn-danger"
                                >
                                    Eliminar
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default AxiosDjango;
